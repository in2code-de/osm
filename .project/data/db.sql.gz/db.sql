-- MariaDB dump 10.19  Distrib 10.11.19-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `uc` mediumblob DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1737380305,1737378764,0,0,0,0,NULL,'default','a:5:{s:10:\"moduleData\";a:4:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:3:{s:32:\"89494ca03c0d71614c20797c37296c5a\";a:5:{i:0;s:5:\"admin\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"be_users\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bbe_users%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"be_users\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=32d92622ef1891728c4a9cf372d15dc095c05313&id=0&table=&pointer=1\";}s:32:\"f57bfe059e0f0ba18b34482f921a7db9\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_address\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_address%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_address\";s:3:\"uid\";i:1;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=32d92622ef1891728c4a9cf372d15dc095c05313&id=2&table=&pointer=1\";}s:32:\"deac478137dd48a97e299bd046412e21\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=3a3e8fa57bcfe9d4582b700b966bc7ac99dead2a&id=1#element-tt_content-2\";}}i:1;s:32:\"f57bfe059e0f0ba18b34482f921a7db9\";}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:18:\"pagetsconfig_pages\";}s:9:\"clipboard\";a:5:{s:6:\"normal\";a:2:{s:2:\"el\";a:0:{}s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:4:{s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"ef998d64819fe248ce42ea8fb8d2978508141f92\";s:10:\"FormEngine\";s:40:\"ef998d64819fe248ce42ea8fb8d2978508141f92\";s:12:\"pagetsconfig\";s:40:\"ef998d64819fe248ce42ea8fb8d2978508141f92\";s:9:\"clipboard\";s:40:\"ef998d64819fe248ce42ea8fb8d2978508141f92\";}}',0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$QTdSSlNlSTBCNzZiNDVHNA$EPkGpQr9svLtnx9NJdBP+v+gKsHGvsBfr9tRkIVvR50','',0,NULL,'','admin@example.com','',1,3,NULL,1,NULL,'',NULL,1737378774,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_ttaddress_category`
--

DROP TABLE IF EXISTS `cache_ttaddress_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_ttaddress_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_ttaddress_category`
--

LOCK TABLES `cache_ttaddress_category` WRITE;
/*!40000 ALTER TABLE `cache_ttaddress_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_ttaddress_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_ttaddress_category_tags`
--

DROP TABLE IF EXISTS `cache_ttaddress_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_ttaddress_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_ttaddress_category_tags`
--

LOCK TABLES `cache_ttaddress_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_ttaddress_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_ttaddress_category_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_ttaddress_geocoding`
--

DROP TABLE IF EXISTS `cache_ttaddress_geocoding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_ttaddress_geocoding` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_ttaddress_geocoding`
--

LOCK TABLES `cache_ttaddress_geocoding` WRITE;
/*!40000 ALTER TABLE `cache_ttaddress_geocoding` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_ttaddress_geocoding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_ttaddress_geocoding_tags`
--

DROP TABLE IF EXISTS `cache_ttaddress_geocoding_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_ttaddress_geocoding_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_ttaddress_geocoding_tags`
--

LOCK TABLES `cache_ttaddress_geocoding_tags` WRITE;
/*!40000 ALTER TABLE `cache_ttaddress_geocoding_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_ttaddress_geocoding_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1737378803,1737378790,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"description\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,1794574283,0,0,0,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'','',''),
(2,5,1794574099,1737382001,0,0,0,0,'',512,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\"}',0,0,0,0,1,0,31,27,0,1794844570,0,0,0,1,'Pi2','/default-templates/pi2',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',''),
(3,5,1794574106,1794573912,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\"}',0,0,0,0,3,0,31,27,0,1794994060,0,0,0,1,'Pi1','/default-templates/pi1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',''),
(4,1,1794574006,1794574003,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,0,31,27,0,0,0,0,0,254,'tt_address','/tt-address',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',''),
(5,1,1794574068,1794574065,0,0,0,0,'0',64,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,0,31,27,0,1794574416,0,0,0,1,'Default Templates','/default-templates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',''),
(6,1,1794574154,1794574122,0,0,0,0,'0',288,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,0,31,27,0,1794574431,0,0,0,1,'OpenLayers10 Templates','/default-templates/pi2/openlayers10-templates',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',''),
(7,6,1794574226,1794574171,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,0,31,27,0,1794994046,0,0,0,1,'Pi1','/openlayers10-templates/pi1',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',''),
(8,6,1794574229,1794574204,0,0,0,0,'',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,0,31,27,0,1794844579,0,0,0,1,'Pi2','/openlayers10-templates/pi2',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `size` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1737378827,1737378827,'/_assets/6666cd76f96956469e7be39d750cc7d9/Icons/Extension.svg','1c829132b2e1b32caa87888dc6ff9ce8be61bb72','0026fcfdb26a70aa3b71a1e66845e7199fc0f517','svg','Extension.svg','b815a8cd36ab60cba6ccf6c36b5876bc486104c9',1737378434,1737378434,0,2,'image/svg+xml',1132,0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1737378827,1737378827,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,500,500);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1737378827,1737378827,0,1,'',NULL,'','a:7:{s:5:\"width\";i:30;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b70510335580ae50fb19c7a0f2dcbda134776d7f','b815a8cd36ab60cba6ccf6c36b5876bc486104c9','Image.CropScaleMask','da5c30a12f',30,30);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1737378796,1737378796,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1737378790,1,'BE',1,0,1,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":0,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Home\",\"crdate\":1737378790,\"t3ver_stage\":0,\"tstamp\":1737378790,\"uid\":1}',0,'0400$c276a8d780c194fb886e348e8b2b9c1f:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1737378793,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$97f2bf31ef037164b8f720a6198805a8:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1737378803,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$f8c76e1783e9fc3e556d583b0afe33e2:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1737378820,1,'BE',1,0,1,'tt_content','{\"CType\":\"list\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"osm_pi1\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1737378820,\"t3ver_stage\":0,\"tstamp\":1737378820,\"uid\":1}',0,'0400$4c698f8175634229287d2993c0a10f8c:7fa2c035f26826fe83eeecaaeddc4d40'),
(5,1737378859,1,'BE',1,0,1,'sys_template','{\"root\":\"1\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":\"0\",\"static_file_mode\":\"0\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":256,\"title\":\"MAIN TEMPLATE\",\"constants\":\"\",\"config\":\"\",\"clear\":\"0\",\"include_static_file\":\"EXT:osm\\/Configuration\\/TypoScript\\/\",\"description\":\"\",\"crdate\":1737378859,\"tstamp\":1737378859,\"uid\":1}',0,'0400$db56ba73971a6d6e818d800a47874898:35af6288617af54964e77af08c30949a'),
(6,1737379335,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:osm\\/Configuration\\/TypoScript\\/\"},\"newRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:osm\\/Configuration\\/TypoScript\\/\"}}',0,'0400$ab70641ef08cdc97f74221ddf738d8c4:35af6288617af54964e77af08c30949a'),
(7,1737379444,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\"},\"newRecord\":{\"config\":\"page = PAGE\\r\\npage.10 < styles.content.get\"}}',0,'0400$9c0831ac16c1c21615028e8afc8b105a:35af6288617af54964e77af08c30949a'),
(8,1737379590,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$0c3c598b6524722a769493e939204e4a:7fa2c035f26826fe83eeecaaeddc4d40'),
(9,1737380305,2,'BE',1,0,1,'be_users','{\"oldRecord\":{\"username\":\"anedbal\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$QXJTUjVOcFRaMUY5WW5qNg$dXbLSibGMY5QuA8aDE4uwIOptt6MenhNZhpqlb7CotM\",\"realName\":\"Andreas Nedbal\",\"email\":\"andreas.nedbal@in2code.de\"},\"newRecord\":{\"username\":\"admin\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$QTdSSlNlSTBCNzZiNDVHNA$EPkGpQr9svLtnx9NJdBP+v+gKsHGvsBfr9tRkIVvR50\",\"realName\":\"\",\"email\":\"admin@example.com\"}}',0,'0400$1d2a9a5f969bd307e55b29c5cc2f5f38:084907bc914ff27cf2301aec50eb66b2'),
(10,1737380830,1,'BE',1,0,2,'tt_content','{\"CType\":\"list\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"osm_pi2\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":512,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.addresses\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1737380830,\"t3ver_stage\":0,\"tstamp\":1737380830,\"uid\":2}',0,'0400$2a8649571252b54dd983a263fb2839b4:01dbc21fdb1263685b9147b3b1596ea8'),
(11,1737380917,1,'BE',1,0,1,'tt_address','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"gender\":\"\",\"slug\":\"default-e2dbe02fa8f2089ddc2962fb738965ec\",\"categories\":\"0\",\"pid\":1,\"sorting\":256,\"title\":\"\",\"title_suffix\":\"\",\"first_name\":\"\",\"middle_name\":\"\",\"last_name\":\"\",\"name\":\"\",\"description\":\"\",\"address\":\"Geschwister-Scholl-Platz\",\"city\":\"T\\u00fcbingen\",\"zip\":\"72074\",\"region\":\"\",\"country\":\"Germany\",\"latitude\":\"48.52441205\",\"longitude\":\"9.05972173\",\"email\":\"\",\"phone\":\"\",\"mobile\":\"\",\"fax\":\"\",\"www\":\"\",\"birthday\":0,\"position\":\"\",\"company\":\"\",\"building\":\"\",\"room\":\"\",\"skype\":\"\",\"twitter\":\"\",\"linkedin\":\"\",\"tiktok\":\"\",\"facebook\":\"\",\"instagram\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"crdate\":1737380917,\"t3ver_stage\":0,\"tstamp\":1737380917,\"uid\":1}',0,'0400$1a5773b15f2588f075c23b3956cfe845:89ad377b42f05d351e785d7afbaa10fe'),
(12,1737380932,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.addresses\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.addresses\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$26fd8ee0989edb76bb69de49b6680d60:01dbc21fdb1263685b9147b3b1596ea8'),
(13,1737382001,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/tt-address\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"tt_address\",\"sys_language_uid\":0,\"crdate\":1737382001,\"t3ver_stage\":0,\"tstamp\":1737382001,\"uid\":2}',0,'0400$09b88a8bb36c725889cc4ecfc67bf4a5:f11830df10b4b0bca2db34810c2241b3'),
(14,1737382005,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$9a3832bb4c798c6ac58a5044c02d71ae:f11830df10b4b0bca2db34810c2241b3'),
(15,1737382012,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$bd63acd1cca243ab6ab1fc9d2a84d028:01dbc21fdb1263685b9147b3b1596ea8'),
(16,1737382012,3,'BE',1,0,2,'tt_content','{\"oldPageId\":1,\"newPageId\":2,\"oldData\":{\"header\":\"[No title]\",\"pid\":1,\"event_pid\":1,\"t3ver_state\":0},\"newData\":{\"tstamp\":1737382012,\"pid\":2,\"sorting\":256}}',0,'0400$bd63acd1cca243ab6ab1fc9d2a84d028:01dbc21fdb1263685b9147b3b1596ea8'),
(17,1737382084,3,'BE',1,0,1,'tt_address','{\"oldPageId\":1,\"newPageId\":2,\"oldData\":{\"header\":\"[No title]\",\"pid\":1,\"event_pid\":1,\"t3ver_state\":0},\"newData\":{\"tstamp\":1737382084,\"pid\":2,\"sorting\":256}}',0,'0400$87939d545cded58231cfa9fe17110f20:89ad377b42f05d351e785d7afbaa10fe'),
(18,1737382100,2,'BE',1,0,1,'tt_address','{\"oldRecord\":{\"name\":\"\",\"image\":null,\"l10n_diffsource\":\"\"},\"newRecord\":{\"name\":\"Universit\\u00e4t T\\u00fcbingen\",\"image\":0,\"l10n_diffsource\":\"{\\\"gender\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"title_suffix\\\":\\\"\\\",\\\"first_name\\\":\\\"\\\",\\\"middle_name\\\":\\\"\\\",\\\"last_name\\\":\\\"\\\",\\\"name\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"address\\\":\\\"\\\",\\\"city\\\":\\\"\\\",\\\"zip\\\":\\\"\\\",\\\"region\\\":\\\"\\\",\\\"country\\\":\\\"\\\",\\\"latitude\\\":\\\"\\\",\\\"longitude\\\":\\\"\\\",\\\"email\\\":\\\"\\\",\\\"phone\\\":\\\"\\\",\\\"mobile\\\":\\\"\\\",\\\"fax\\\":\\\"\\\",\\\"www\\\":\\\"\\\",\\\"birthday\\\":\\\"\\\",\\\"position\\\":\\\"\\\",\\\"company\\\":\\\"\\\",\\\"building\\\":\\\"\\\",\\\"room\\\":\\\"\\\",\\\"skype\\\":\\\"\\\",\\\"twitter\\\":\\\"\\\",\\\"linkedin\\\":\\\"\\\",\\\"tiktok\\\":\\\"\\\",\\\"facebook\\\":\\\"\\\",\\\"instagram\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"categories\\\":\\\"\\\"}\"}}',0,'0400$66be954acc592664bd75f23f28eb4092:89ad377b42f05d351e785d7afbaa10fe'),
(19,1794573817,1,'BE',2,0,3,'be_users','{\"admin\":1,\"options\":3,\"file_permissions\":\"readFolder,writeFolder,addFolder,renameFolder,moveFolder,deleteFolder,readFile,writeFile,addFile,renameFile,replaceFile,moveFile,copyFile,deleteFile\",\"workspace_perms\":1,\"lang\":\"default\",\"lastlogin\":0,\"disable\":0,\"starttime\":0,\"endtime\":0,\"pid\":0,\"username\":\"et.richard.klein\",\"password\":\"$argon2i$v=19$m=65536,t=16,p=1$bHBZQjl3c0x3WVpaMDZ2Wg$PqJvHUXj7rPtm1M9jDbid1yyYVIDSm0P9hz6opMQC3A\",\"email\":\"richard.klein@elementare-teilchen.de\",\"usergroup\":\"\",\"crdate\":1794573817,\"tstamp\":1794573817,\"uid\":3}',0,'0400$t1KsbHcZdwmj4M06iuWF0fFieWLQA75e:0c759eb140de7eba987dfc32521df385'),
(20,1794573912,1,'BE',3,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/default-pi1\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":128,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Default-Pi1\",\"sys_language_uid\":0,\"crdate\":1794573912,\"t3ver_stage\":0,\"tstamp\":1794573912,\"uid\":3}',0,'0400$_4v97u5eHPsAAFj0gq5DKk2QaYzQhMjq:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(21,1794573936,2,'BE',3,0,2,'pages','{\"oldRecord\":{\"title\":\"tt_address\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"title\":\"Default-Pi2\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\"}\"}}',0,'0400$hCQ5XfRZZ2mT5xw1wm7UC60BoTl4BZP3:f11830df10b4b0bca2db34810c2241b3'),
(22,1794573940,2,'BE',3,0,2,'pages','{\"oldRecord\":{\"slug\":\"\\/tt-address\"},\"newRecord\":{\"slug\":\"\\/default-pi2\"}}',0,'0400$Jzz1gLQijrEBftC5ChNPfF33klMkX37h:f11830df10b4b0bca2db34810c2241b3'),
(23,1794573946,2,'BE',3,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$nFcq9wLLMvaGRAL_lJH0e5oSYDVvxpoD:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(24,1794573977,3,'BE',3,0,1,'tt_content','{\"oldData\":{\"pid\":1,\"tstamp\":1737379590,\"sorting\":256},\"newData\":{\"tstamp\":1794573977,\"sorting\":256,\"pid\":3}}',0,'0400$qnAj9PdRUsU9sCJOKaVOhSOBvC_yCfI9:7fa2c035f26826fe83eeecaaeddc4d40'),
(25,1794574003,1,'BE',3,0,4,'pages','{\"doktype\":\"254\",\"slug\":\"\\/tt-address\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":512,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"tt_address\",\"sys_language_uid\":0,\"crdate\":1794574003,\"t3ver_stage\":0,\"tstamp\":1794574003,\"uid\":4}',0,'0400$92TYrT5ryUPhXr9e81Zqo_vOW_o3qhLf:412add0b3eb6ec8f1cb6710aea92e21e'),
(26,1794574006,2,'BE',3,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$VL9ygvX32Y6nEI_IbdYMvu066k-JjpWO:412add0b3eb6ec8f1cb6710aea92e21e'),
(27,1794574016,3,'BE',3,0,1,'tt_address','{\"oldData\":{\"pid\":2,\"tstamp\":1737382100,\"sorting\":256},\"newData\":{\"tstamp\":1794574016,\"sorting\":256,\"pid\":4}}',0,'0400$bdNyvgXgJgEw3tMyDdQkRp-NPd2EgRKx:89ad377b42f05d351e785d7afbaa10fe'),
(28,1794574055,2,'BE',3,0,3,'pages','{\"oldRecord\":{\"title\":\"Default-Pi1\",\"slug\":\"\\/default-pi1\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"title\":\"Pi1\",\"slug\":\"\\/pi1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\"}\"}}',0,'0400$5cT9fS5rah_Yosi_LHD3fJSbvS9nMAh4:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(29,1794574065,1,'BE',3,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/default-templates\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sorting\":64,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Default Templates\",\"sys_language_uid\":0,\"crdate\":1794574065,\"t3ver_stage\":0,\"tstamp\":1794574065,\"uid\":5}',0,'0400$r3Qy6Xjfr_YDdHHCbH8P_pmk1h0UTakE:7ef5a4e3e11db8ac3fea4d7a75468161'),
(30,1794574068,2,'BE',3,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$mYaPuonbO9coXXxN7009002kxMUyNNjT:7ef5a4e3e11db8ac3fea4d7a75468161'),
(31,1794574081,3,'BE',3,0,3,'pages','{\"oldData\":{\"pid\":1,\"tstamp\":1794574055,\"sorting\":128},\"newData\":{\"tstamp\":1794574081,\"sorting\":256,\"pid\":5}}',0,'0400$jzc2IWVIlCcgxibgUMfpPykBFJpnEDSl:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(32,1794574086,3,'BE',3,0,2,'pages','{\"oldData\":{\"pid\":1,\"tstamp\":1794573940,\"sorting\":256},\"newData\":{\"tstamp\":1794574086,\"sorting\":512,\"pid\":5}}',0,'0400$WiBjukSXCU8PlAHUhzt9oui18hPfaSCZ:f11830df10b4b0bca2db34810c2241b3'),
(33,1794574099,2,'BE',3,0,2,'pages','{\"oldRecord\":{\"title\":\"Default-Pi2\",\"slug\":\"\\/default-pi2\"},\"newRecord\":{\"title\":\"Pi2\",\"slug\":\"\\/default-templates\\/pi2\"}}',0,'0400$gFTtYu4hizvg5iDJ_FYDK9h8i0AuhsOb:f11830df10b4b0bca2db34810c2241b3'),
(34,1794574106,2,'BE',3,0,3,'pages','{\"oldRecord\":{\"slug\":\"\\/pi1\"},\"newRecord\":{\"slug\":\"\\/default-templates\\/pi1\"}}',0,'0400$fy8-Y9Dqn5OngNW7d9jfusEEKUkEyX2K:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(35,1794574122,1,'BE',3,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/default-templates\\/pi2\\/openlayers10-templates\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"OpenLayers10 Templates\",\"sys_language_uid\":0,\"crdate\":1794574122,\"t3ver_stage\":0,\"tstamp\":1794574122,\"uid\":6}',0,'0400$jOoh6g97OQyhHbca6wXUS4GG4EKpMwVy:c75354c439a48dbde16b03ac553a080d'),
(36,1794574143,3,'BE',3,0,6,'pages','{\"oldData\":{\"pid\":2,\"tstamp\":1794574122,\"sorting\":256},\"newData\":{\"tstamp\":1794574143,\"sorting\":32,\"pid\":1}}',0,'0400$DXs2L6xDK1KtluVqKlWMG7R7sXJ8XBSZ:c75354c439a48dbde16b03ac553a080d'),
(37,1794574149,3,'BE',3,0,6,'pages','{\"oldData\":{\"pid\":1,\"tstamp\":1794574143,\"sorting\":32},\"newData\":{\"tstamp\":1794574149,\"sorting\":288,\"pid\":1}}',0,'0400$h7Fr4CBPfNwYVmWU_72kb1dhTq5dySNx:c75354c439a48dbde16b03ac553a080d'),
(38,1794574154,2,'BE',3,0,6,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$d4iz8RERdULPsC8ZLSeA0aXpoVc5pvZb:c75354c439a48dbde16b03ac553a080d'),
(39,1794574171,1,'BE',3,0,7,'pages','{\"doktype\":\"1\",\"slug\":\"\\/default-templates\\/pi1-1\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\"}\",\"pid\":6,\"sorting\":256,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"title\":\"Pi1\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"no_search\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"crdate\":1794574171,\"t3ver_stage\":0,\"tstamp\":1794574171,\"uid\":7}',0,'0400$2schurQ8cn-rk0jIwwr6PAe-EBeCAZi-:df50bb24cbce671cf0d61f42fbbef601'),
(40,1794574171,1,'BE',3,0,3,'tt_content','{\"CType\":\"list\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"osm_pi1\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":7,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"crdate\":1794574171,\"t3ver_stage\":0,\"tstamp\":1794574171,\"uid\":3}',0,'0400$FuyHSNhUVC3lyrxKe6qL9byCQ7_UeelV:b92300cfb5d1d3645c9cb212a7f56c1f'),
(41,1794574194,2,'BE',3,0,7,'pages','{\"oldRecord\":{\"slug\":\"\\/default-templates\\/pi1-1\"},\"newRecord\":{\"slug\":\"\\/openlayers10-templates\\/pi1\"}}',0,'0400$vxJ64PaDPqRflo6OGysmIJlbFz3rnoEs:df50bb24cbce671cf0d61f42fbbef601'),
(42,1794574204,1,'BE',3,0,8,'pages','{\"doktype\":\"1\",\"slug\":\"\\/default-templates\\/pi2-1\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\"}\",\"pid\":6,\"sorting\":512,\"perms_userid\":3,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"title\":\"Pi2\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"no_search\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"is_siteroot\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"crdate\":1794574204,\"t3ver_stage\":0,\"tstamp\":1794574204,\"uid\":8}',0,'0400$B2RxrhP_VaTSeBOC4EqGwmttZSG8bS_p:595375f2fb9f014e091eb08fbc51ec88'),
(43,1794574204,1,'BE',3,0,4,'tt_content','{\"CType\":\"list\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"osm_pi2\",\"sectionIndex\":1,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":8,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.addresses\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"crdate\":1794574204,\"t3ver_stage\":0,\"tstamp\":1794574204,\"uid\":4}',0,'0400$AdB0ZtFO8iFHEaA8CacPKK0HUEVsb5vj:4d391f5ef79b8d5d10dffa8a07ca167d'),
(44,1794574217,2,'BE',3,0,8,'pages','{\"oldRecord\":{\"slug\":\"\\/default-templates\\/pi2-1\"},\"newRecord\":{\"slug\":\"\\/openlayers10-templates\\/pi2\"}}',0,'0400$xASr6lKYR6u9_2yLGbSTWkpKqCX0uyaG:595375f2fb9f014e091eb08fbc51ec88'),
(45,1794574226,2,'BE',3,0,7,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$0JXx8r0A0iJP8StqX3tQmtmgPUuejann:df50bb24cbce671cf0d61f42fbbef601'),
(46,1794574229,2,'BE',3,0,8,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$RlgaMuKaZ1gJrY6TyiLzYXYGOJz-jEK_:595375f2fb9f014e091eb08fbc51ec88'),
(47,1794574261,1,'BE',3,0,5,'tt_content','{\"CType\":\"menu_subpages\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":1,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pages\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1794574261,\"t3ver_stage\":0,\"tstamp\":1794574261,\"uid\":5}',0,'0400$u0ETgnS6mf8LFqdi7C7twCZDVuo01xu1:c7626fc9bcba6f70beb6ebc085a400db'),
(48,1794574283,2,'BE',3,0,5,'tt_content','{\"oldRecord\":{\"CType\":\"menu_subpages\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"CType\":\"menu_sitemap_pages\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$KooKBlqvEH37aJTpKvz606NnlrX8dBSi:c7626fc9bcba6f70beb6ebc085a400db'),
(49,1794574416,1,'BE',3,0,6,'tt_content','{\"CType\":\"menu_subpages\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pages\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1794574416,\"t3ver_stage\":0,\"tstamp\":1794574416,\"uid\":6}',0,'0400$8Ubf4cfMcaUC5UdNRTHxhpG7AOyGFYRr:c0db6803ab1ec5f70c36e2a72187867b'),
(50,1794574431,1,'BE',3,0,7,'tt_content','{\"CType\":\"menu_subpages\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pages\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1794574431,\"t3ver_stage\":0,\"tstamp\":1794574431,\"uid\":7}',0,'0400$URbr-cufaD-m6HNaagvT7l0XztvXy6Tb:ea41b626baac59a1fe0716bc344af5d9'),
(51,1794574560,1,'BE',3,0,2,'sys_template','{\"root\":\"0\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":\"0\",\"static_file_mode\":\"0\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":256,\"title\":\"Enable OpenLayers 10 Templates\",\"constants\":\"\",\"config\":\"\",\"clear\":\"0\",\"include_static_file\":\"\",\"description\":\"\",\"crdate\":1794574560,\"tstamp\":1794574560,\"uid\":2}',0,'0400$n0x6hdqenNuof0cDlq42TopdhCLKOI8S:092a6d165d49be6de27c1b2c5d7d6698'),
(52,1794574651,2,'BE',3,0,2,'sys_template','{\"oldRecord\":{\"constants\":\"\"},\"newRecord\":{\"constants\":\"plugin.tx_osm.enableOpenLayers10 = 1\"}}',0,'0400$nEuF_Q5ehDLPIMdcRie6zRvwrkIyaTLx:092a6d165d49be6de27c1b2c5d7d6698'),
(53,1794844470,1,'BE',3,0,2,'tt_address','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"gender\":\"\",\"slug\":\"default-10e20b1bb2726bd4600aae57878a70ad\",\"categories\":\"0\",\"pid\":4,\"sorting\":128,\"title\":\"\",\"title_suffix\":\"\",\"first_name\":\"\",\"middle_name\":\"\",\"last_name\":\"\",\"name\":\"Alter Botanischer Garten\",\"description\":\"\",\"address\":\"\",\"city\":\"\",\"zip\":\"\",\"region\":\"\",\"country\":\"\",\"latitude\":\"48.52347617\",\"longitude\":\"9.05672014\",\"email\":\"\",\"phone\":\"\",\"mobile\":\"\",\"fax\":\"\",\"www\":\"\",\"birthday\":0,\"position\":\"\",\"company\":\"\",\"building\":\"\",\"room\":\"\",\"skype\":\"\",\"twitter\":\"\",\"linkedin\":\"\",\"tiktok\":\"\",\"facebook\":\"\",\"instagram\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"crdate\":1794844470,\"t3ver_stage\":0,\"tstamp\":1794844470,\"uid\":2}',0,'0400$eEYHTb_bxuXHy5D0qIWVagPS_lg0-tVG:e395bf283af5aba9042025a35c5575c6'),
(54,1794844563,1,'BE',3,0,3,'tt_address','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"gender\":\"\",\"slug\":\"default-8dffda840c8fd42d91e9af9e899f2383\",\"categories\":\"0\",\"pid\":4,\"sorting\":64,\"title\":\"\",\"title_suffix\":\"\",\"first_name\":\"\",\"middle_name\":\"\",\"last_name\":\"\",\"name\":\"Technisches Rathaus\",\"description\":\"\",\"address\":\"\",\"city\":\"\",\"zip\":\"\",\"region\":\"\",\"country\":\"\",\"latitude\":\"48.52339089\",\"longitude\":\"9.06025528\",\"email\":\"\",\"phone\":\"\",\"mobile\":\"\",\"fax\":\"\",\"www\":\"\",\"birthday\":0,\"position\":\"\",\"company\":\"\",\"building\":\"\",\"room\":\"\",\"skype\":\"\",\"twitter\":\"\",\"linkedin\":\"\",\"tiktok\":\"\",\"facebook\":\"\",\"instagram\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"crdate\":1794844563,\"t3ver_stage\":0,\"tstamp\":1794844563,\"uid\":3}',0,'0400$L-CAUqpODpiL7-BcuRtzSB5jnKPJJ8QJ:3e5050661eff18f173320aa97404439f'),
(55,1794844570,2,'BE',3,0,2,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.addresses\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.addresses\\\">\\n                    <value index=\\\"vDEF\\\">1,2,3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$_G37duHkZMHQRQw6Rb-PbOskRf-qNQo4:01dbc21fdb1263685b9147b3b1596ea8'),
(56,1794844579,2,'BE',3,0,4,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.addresses\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.addresses\\\">\\n                    <value index=\\\"vDEF\\\">1,2,3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$YGrRTd3-lALNsSpl3IqtS6Rbz7qkfHOT:4d391f5ef79b8d5d10dffa8a07ca167d'),
(57,1794908657,2,'BE',3,0,1,'tt_address','{\"oldRecord\":{\"title\":\"\",\"l10n_diffsource\":\"{\\\"gender\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"title_suffix\\\":\\\"\\\",\\\"first_name\\\":\\\"\\\",\\\"middle_name\\\":\\\"\\\",\\\"last_name\\\":\\\"\\\",\\\"name\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"address\\\":\\\"\\\",\\\"city\\\":\\\"\\\",\\\"zip\\\":\\\"\\\",\\\"region\\\":\\\"\\\",\\\"country\\\":\\\"\\\",\\\"latitude\\\":\\\"\\\",\\\"longitude\\\":\\\"\\\",\\\"email\\\":\\\"\\\",\\\"phone\\\":\\\"\\\",\\\"mobile\\\":\\\"\\\",\\\"fax\\\":\\\"\\\",\\\"www\\\":\\\"\\\",\\\"birthday\\\":\\\"\\\",\\\"position\\\":\\\"\\\",\\\"company\\\":\\\"\\\",\\\"building\\\":\\\"\\\",\\\"room\\\":\\\"\\\",\\\"skype\\\":\\\"\\\",\\\"twitter\\\":\\\"\\\",\\\"linkedin\\\":\\\"\\\",\\\"tiktok\\\":\\\"\\\",\\\"facebook\\\":\\\"\\\",\\\"instagram\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"categories\\\":\\\"\\\"}\"},\"newRecord\":{\"title\":\"Universit\\u00e4t T\\u00fcbingen\",\"l10n_diffsource\":\"{\\\"address\\\":\\\"\\\",\\\"birthday\\\":\\\"\\\",\\\"building\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"city\\\":\\\"\\\",\\\"company\\\":\\\"\\\",\\\"country\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"email\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"facebook\\\":\\\"\\\",\\\"fax\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"first_name\\\":\\\"\\\",\\\"gender\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"instagram\\\":\\\"\\\",\\\"last_name\\\":\\\"\\\",\\\"latitude\\\":\\\"\\\",\\\"linkedin\\\":\\\"\\\",\\\"longitude\\\":\\\"\\\",\\\"middle_name\\\":\\\"\\\",\\\"mobile\\\":\\\"\\\",\\\"name\\\":\\\"\\\",\\\"phone\\\":\\\"\\\",\\\"position\\\":\\\"\\\",\\\"region\\\":\\\"\\\",\\\"room\\\":\\\"\\\",\\\"skype\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tiktok\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"title_suffix\\\":\\\"\\\",\\\"twitter\\\":\\\"\\\",\\\"www\\\":\\\"\\\",\\\"zip\\\":\\\"\\\"}\"}}',0,'0400$kDzIASBQCySnpDpRTgJaJ8xcEAAAVevB:89ad377b42f05d351e785d7afbaa10fe'),
(58,1794908681,2,'BE',3,0,1,'tt_address','{\"oldRecord\":{\"title\":\"Universit\\u00e4t T\\u00fcbingen\"},\"newRecord\":{\"title\":\"\"}}',0,'0400$87hHdc3kz1cWCcVUyXPKEAz8zvMl_XyL:89ad377b42f05d351e785d7afbaa10fe'),
(59,1794908769,2,'BE',3,0,2,'tt_address','{\"oldRecord\":{\"name\":\"Alter Botanischer Garten\",\"image\":null,\"description\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"name\":\"Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behaviot\",\"image\":0,\"description\":\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. \\r\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. \\r\\nStet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\",\"l10n_diffsource\":\"{\\\"address\\\":\\\"\\\",\\\"birthday\\\":\\\"\\\",\\\"building\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"city\\\":\\\"\\\",\\\"company\\\":\\\"\\\",\\\"country\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"email\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"facebook\\\":\\\"\\\",\\\"fax\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"first_name\\\":\\\"\\\",\\\"gender\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"instagram\\\":\\\"\\\",\\\"last_name\\\":\\\"\\\",\\\"latitude\\\":\\\"\\\",\\\"linkedin\\\":\\\"\\\",\\\"longitude\\\":\\\"\\\",\\\"middle_name\\\":\\\"\\\",\\\"mobile\\\":\\\"\\\",\\\"name\\\":\\\"\\\",\\\"phone\\\":\\\"\\\",\\\"position\\\":\\\"\\\",\\\"region\\\":\\\"\\\",\\\"room\\\":\\\"\\\",\\\"skype\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tiktok\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"title_suffix\\\":\\\"\\\",\\\"twitter\\\":\\\"\\\",\\\"www\\\":\\\"\\\",\\\"zip\\\":\\\"\\\"}\"}}',0,'0400$vhfJ8wC-20W2Hn7gBj_e4rZcAxd4PAbD:e395bf283af5aba9042025a35c5575c6'),
(60,1794910899,2,'BE',3,0,2,'tt_address','{\"oldRecord\":{\"name\":\"Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behaviot\"},\"newRecord\":{\"name\":\"Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior\"}}',0,'0400$OOulAczRHqAt_YDeZKZaPCaXIoEsYXpW:e395bf283af5aba9042025a35c5575c6'),
(61,1794913198,2,'BE',3,0,2,'tt_address','{\"oldRecord\":{\"description\":\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. \\r\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. \\r\\nStet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\"},\"newRecord\":{\"description\":\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\r\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\r\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\"}}',0,'0400$1k_EMFKyoTWAnS_fu_v7JdBe6AVNauKw:e395bf283af5aba9042025a35c5575c6'),
(62,1794992928,2,'BE',3,0,1,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Universit\\u00e4t T\\u00fcbingen<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6acabb44a367896477\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52339089<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.06025528<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Technisches Rathaus<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$KD3pi0Gg_ERo2bBf-obx6-6cZB-aeIHW:7fa2c035f26826fe83eeecaaeddc4d40'),
(63,1794992992,2,'BE',3,0,1,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Universit\\u00e4t T\\u00fcbingen<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6acabb44a367896477\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52339089<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.06025528<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Technisches Rathaus<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Universit\\u00e4t T\\u00fcbingen<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6acabb44a367896477\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52339089<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.06025528<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Technisches Rathaus<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6b3b42f3a140394427\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52347617<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05672014<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">0<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$L1kAK7dMnZdAHNDZzqLUoLKsTVC-QSn_:7fa2c035f26826fe83eeecaaeddc4d40'),
(64,1794993041,4,'BE',3,0,3,'tt_content',NULL,0,'0400$szpq58l26vCmt9IlxFOi4SNr-jvHIWvD:b92300cfb5d1d3645c9cb212a7f56c1f'),
(65,1794993049,1,'BE',3,0,8,'tt_content','{\"CType\":\"list\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"osm_pi1\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":7,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Universit\\u00e4t T\\u00fcbingen<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6acabb44a367896477\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52339089<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.06025528<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Technisches Rathaus<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6b3b42f3a140394427\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52347617<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05672014<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">0<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"crdate\":1794993049,\"t3ver_stage\":0,\"tstamp\":1794993049,\"uid\":8}',0,'0400$SUIyfE1FjcoIJp9bWNlr8stg98e85JMC:2097d84972a039cb6bfe093b17089287'),
(66,1794993049,2,'BE',3,0,8,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$ljf7CfKp0YYYP0ETGJHzePwc5AE11UHL:2097d84972a039cb6bfe093b17089287'),
(67,1794993069,2,'BE',3,0,8,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"list_type\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$1C7CRPdrBAibnVTfQ4168S1yE3Z1VFcf:2097d84972a039cb6bfe093b17089287'),
(68,1794994046,2,'BE',3,0,8,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Universit\\u00e4t T\\u00fcbingen<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6acabb44a367896477\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52339089<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.06025528<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Technisches Rathaus<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6b3b42f3a140394427\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52347617<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05672014<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">0<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Universit\\u00e4t T\\u00fcbingen<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6acabb44a367896477\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52339089<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.06025528<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Technisches Rathaus<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6b3b42f3a140394427\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52347617<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05672014<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$VTk-9XgjUSjfBulpsSID3DrUJ9kN4_6_:2097d84972a039cb6bfe093b17089287'),
(69,1794994060,2,'BE',3,0,1,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Universit\\u00e4t T\\u00fcbingen<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6acabb44a367896477\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52339089<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.06025528<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Technisches Rathaus<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6b3b42f3a140394427\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52347617<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05672014<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">0<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.zoom\\\">\\n                    <value index=\\\"vDEF\\\">14<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.addresses\\\">\\n                    <el index=\\\"el\\\">\\n                        <field index=\\\"678e4e92e348b293865823\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\">Geschwister-Scholl-Platz, 72074 T\\u00fcbingen, Deutschland<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52441205<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05972173<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Universit\\u00e4t T\\u00fcbingen<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6acabb44a367896477\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52339089<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.06025528<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Technisches Rathaus<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                        <field index=\\\"6afd6b3b42f3a140394427\\\">\\n                            <value index=\\\"config\\\">\\n                                <el>\\n                                    <field index=\\\"address\\\">\\n                                        <value index=\\\"vDEF\\\"><\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"latitude\\\">\\n                                        <value index=\\\"vDEF\\\">48.52347617<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"longitude\\\">\\n                                        <value index=\\\"vDEF\\\">9.05672014<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"marker\\\">\\n                                        <value index=\\\"vDEF\\\">1<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markertitle\\\">\\n                                        <value index=\\\"vDEF\\\">Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior<\\/value>\\n                                    <\\/field>\\n                                    <field index=\\\"markerdescription\\\">\\n                                        <value index=\\\"vDEF\\\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/value>\\n                                    <\\/field>\\n                                <\\/el>\\n                            <\\/value>\\n                        <\\/field>\\n                    <\\/el>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$c_XBQckm2P1ejX050YNh7IgCy2vjQ5LS:7fa2c035f26826fe83eeecaaeddc4d40');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES
(20,1,1737382101,'tt_address',1,0,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1737378774,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'192.168.155.5','[\"anedbal\"]',-1,-99,'','',0,'','info',NULL,NULL),
(2,1737378790,1,1,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'192.168.155.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":1,\"pageTitle\":\"[root-level]\",\"pid\":0}',0,0,'NEWdb403bb','',0,'','info',NULL,NULL),
(3,1737378793,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',1,0,'','',0,'','info',NULL,NULL),
(4,1737378803,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',1,0,'','',0,'','info',NULL,NULL),
(5,1737378820,1,1,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW678e4c00e1d40281925662','',0,'','info',NULL,NULL),
(6,1737378859,1,1,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'192.168.155.5','{\"title\":\"MAIN TEMPLATE\",\"table\":\"sys_template\",\"uid\":1,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW678e4c1674861547531284','',0,'','info',NULL,NULL),
(7,1737379178,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No page configured for type=0. | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/.build/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 48. Requested URL: https://osm.ddev.site/',5,'php',0,'192.168.155.5','',-1,0,'','',0,'','error',NULL,NULL),
(8,1737379218,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476050190: Unable to generate a URL for the named route \"system_config\" because this route was not found. | TYPO3\\CMS\\Backend\\Routing\\Exception\\RouteNotFoundException thrown in file /var/www/html/.build/vendor/typo3/cms-backend/Classes/Routing/UriBuilder.php in line 162. Requested URL: https://osm.ddev.site/typo3/module/tools/csp?token=--AnonymizedToken--',5,'php',0,'192.168.155.5','',-1,0,'','',0,'','error',NULL,NULL),
(9,1737379335,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"MAIN TEMPLATE\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"6\"}',0,0,'','',0,'','info',NULL,NULL),
(10,1737379444,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"MAIN TEMPLATE\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"7\"}',0,0,'','',0,'','info',NULL,NULL),
(11,1737379590,1,2,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":1,\"history\":\"8\"}',0,0,'','',0,'','info',NULL,NULL),
(12,1737380305,1,2,1,'be_users',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"admin\",\"table\":\"be_users\",\"uid\":1,\"history\":\"9\"}',0,0,'','',0,'','info',NULL,NULL),
(13,1737380641,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1439569743: Field settings.addresses of table tt_content reference to foreign table tt_address, but this table is not defined in TCA | UnexpectedValueException thrown in file /var/www/html/.build/vendor/typo3/cms-backend/Classes/Form/FormDataProvider/AbstractItemProvider.php in line 307. Requested URL: https://osm.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Btt_content%%5D%%5B-1%%5D=new&returnUrl=/typo3/module/web/layout?token%%3D--AnonymizedToken--%%26id%%3D1&defVals%%5Btt_content%%5D%%5BCType%%5D=list&defVals%%5Btt_content%%5D%%5Blist_type%%5D=osm_pi2&defVals%%5Btt_content%%5D%%5BcolPos%%5D=0&defVals%%5Btt_content%%5D%%5Bsys_language_uid%%5D=0',5,'php',0,'192.168.155.5','',-1,0,'','',0,'','error',NULL,NULL),
(14,1737380830,1,1,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":2,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW678e53d679c11567742858','',0,'','info',NULL,NULL),
(15,1737380917,1,1,1,'tt_address',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_address\",\"uid\":1,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW678e53e6b5287419337593','',0,'','info',NULL,NULL),
(16,1737380932,1,2,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":2,\"history\":\"12\"}',0,0,'','',0,'','info',NULL,NULL),
(17,1737382001,1,1,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'192.168.155.5','{\"title\":\"tt_address\",\"table\":\"pages\",\"uid\":2,\"pageTitle\":\"Home\",\"pid\":1}',1,0,'NEW2574fd9c','',0,'','info',NULL,NULL),
(18,1737382005,1,2,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"tt_address\",\"table\":\"pages\",\"uid\":2,\"history\":\"14\"}',2,0,'','',0,'','info',NULL,NULL),
(19,1737382012,1,2,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":2,\"history\":\"15\"}',0,0,'','',0,'','info',NULL,NULL),
(20,1737382012,1,4,2,'tt_content',0,0,'Moved record \"{title}\" ({table}:{uid}) to page \"{pageTitle}\" ({pid})',1,'content',2,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":2,\"pageTitle\":\"tt_address\",\"pid\":2}',1,0,'','',0,'','info',NULL,NULL),
(21,1737382012,1,4,2,'tt_content',0,0,'Moved record \"{title}\" ({table}:{uid}) from page \"{pageTitle}\" ({pid}))',1,'content',3,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":2,\"pageTitle\":\"Home\",\"pid\":1}',2,0,'','',0,'','info',NULL,NULL),
(22,1737382084,1,4,1,'tt_address',0,0,'Moved record \"{title}\" ({table}:{uid}) to page \"{pageTitle}\" ({pid})',1,'content',2,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_address\",\"uid\":1,\"pageTitle\":\"tt_address\",\"pid\":2}',1,0,'','',0,'','info',NULL,NULL),
(23,1737382084,1,4,1,'tt_address',0,0,'Moved record \"{title}\" ({table}:{uid}) from page \"{pageTitle}\" ({pid}))',1,'content',3,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_address\",\"uid\":1,\"pageTitle\":\"Home\",\"pid\":1}',2,0,'','',0,'','info',NULL,NULL),
(24,1737382100,1,2,1,'tt_address',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'192.168.155.5','{\"title\":\"[No title]\",\"table\":\"tt_address\",\"uid\":1,\"history\":\"18\"}',0,0,'','',0,'','info',NULL,NULL),
(25,1794573817,2,1,3,'be_users',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'','{\"table\":\"be_users\",\"uid\":3,\"pid\":0}',0,0,'','',0,'','info',NULL,NULL),
(26,1794573862,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.20.0.8','[\"et.richard.klein\"]',-1,-99,'','',0,'','info',NULL,NULL),
(27,1794573912,3,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(28,1794573919,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','a5da73d13add0',1794573919.1945,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(29,1794573928,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','7c79d1cf7c414',1794573928.231,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(30,1794573936,3,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":2,\"history\":\"21\"}',1,0,'','',0,'','info',NULL,NULL),
(31,1794573937,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','1adbe956d398a',1794573937.0335,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(32,1794573940,3,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":2,\"history\":\"22\"}',1,0,'','',0,'','info',NULL,NULL),
(33,1794573940,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','48b74a26d2c90',1794573940.2155,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(34,1794573943,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','85fa88888504d',1794573943.4444,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(35,1794573946,3,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":3,\"history\":\"23\"}',1,0,'','',0,'','info',NULL,NULL),
(36,1794573946,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','1059c8f8f33c6',1794573946.4041,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(37,1794573947,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','947cdf9eb13f0',1794573947.8305,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(38,1794573977,3,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"config\" in /var/www/html/.build/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 4699',5,'php',0,'172.20.0.8','',-1,0,'','',0,'','warning',NULL,NULL),
(39,1794573977,3,4,1,'tt_content',0,0,'Moved record {table}:{uid} to page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":1,\"pid\":3}',1,0,'','',0,'','info',NULL,NULL),
(40,1794573977,3,4,1,'tt_content',0,0,'Moved record {table}:{uid} from page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":1,\"pid\":1}',3,0,'','',0,'','info',NULL,NULL),
(41,1794574003,3,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":4,\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(42,1794574006,3,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":4,\"history\":\"26\"}',1,0,'','',0,'','info',NULL,NULL),
(43,1794574016,3,4,1,'tt_address',0,0,'Moved record {table}:{uid} to page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":1,\"pid\":4}',2,0,'','',0,'','info',NULL,NULL),
(44,1794574016,3,4,1,'tt_address',0,0,'Moved record {table}:{uid} from page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":1,\"pid\":2}',4,0,'','',0,'','info',NULL,NULL),
(45,1794574046,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','61014acf1808e',1794574046.6561,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(46,1794574055,3,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":3,\"history\":\"28\"}',1,0,'','',0,'','info',NULL,NULL),
(47,1794574055,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','b47ed36deee18',1794574055.7447,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(48,1794574065,3,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(49,1794574068,3,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":5,\"history\":\"30\"}',1,0,'','',0,'','info',NULL,NULL),
(50,1794574081,3,4,3,'pages',0,0,'Moved record {table}:{uid} to page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":3,\"pid\":5}',1,0,'','',0,'','info',NULL,NULL),
(51,1794574081,3,4,3,'pages',0,0,'Moved record {table}:{uid} from page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',5,0,'','',0,'','info',NULL,NULL),
(52,1794574086,3,4,2,'pages',0,0,'Moved record {table}:{uid} to page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":2,\"pid\":5}',1,0,'','',0,'','info',NULL,NULL),
(53,1794574086,3,4,2,'pages',0,0,'Moved record {table}:{uid} from page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',5,0,'','',0,'','info',NULL,NULL),
(54,1794574089,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','799d5bd66ca28',1794574089.4282,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(55,1794574099,3,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":2,\"history\":\"33\"}',5,0,'','',0,'','info',NULL,NULL),
(56,1794574099,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','68b5896b4efaa',1794574099.4157,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(57,1794574103,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','8f682f936f8a2',1794574103.6842,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(58,1794574106,3,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":3,\"history\":\"34\"}',5,0,'','',0,'','info',NULL,NULL),
(59,1794574106,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','b6a1afcd2945f',1794574106.1971,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(60,1794574122,3,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":6,\"pid\":2}',2,0,'','',0,'','info',NULL,NULL),
(61,1794574131,3,4,6,'pages',0,1,'Attempt to move pages:{uid} to inside of its own rootline',1,'content',0,'172.20.0.8','{\"uid\":6}',-1,0,'','',0,'','info',NULL,NULL),
(62,1794574143,3,4,6,'pages',0,0,'Moved record {table}:{uid} to page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":6,\"pid\":1}',2,0,'','',0,'','info',NULL,NULL),
(63,1794574143,3,4,6,'pages',0,0,'Moved record {table}:{uid} from page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":6,\"pid\":2}',1,0,'','',0,'','info',NULL,NULL),
(64,1794574149,3,4,6,'pages',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":6,\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(65,1794574154,3,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":6,\"history\":\"38\"}',1,0,'','',0,'','info',NULL,NULL),
(66,1794574171,3,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":7,\"pid\":6}',6,0,'','',0,'','info',NULL,NULL),
(67,1794574171,3,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":3,\"pid\":7}',7,0,'','',0,'','info',NULL,NULL),
(68,1794574174,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','f73047e1d0279',1794574174.9947,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(69,1794574194,3,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":7,\"history\":\"41\"}',6,0,'','',0,'','info',NULL,NULL),
(70,1794574194,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','8be4d7463aa00',1794574194.9212,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(71,1794574204,3,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":8,\"pid\":6}',6,0,'','',0,'','info',NULL,NULL),
(72,1794574204,3,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":4,\"pid\":8}',8,0,'','',0,'','info',NULL,NULL),
(73,1794574204,3,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":4,\"history\":0}',8,0,'','',0,'','info',NULL,NULL),
(74,1794574208,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','0af1233554fe5',1794574208.3212,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(75,1794574217,3,2,8,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":8,\"history\":\"44\"}',6,0,'','',0,'','info',NULL,NULL),
(76,1794574218,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','88d83f75e6623',1794574218.1069,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(77,1794574222,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','2d5e9ff7df187',1794574222.1567,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(78,1794574226,3,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":7,\"history\":\"45\"}',6,0,'','',0,'','info',NULL,NULL),
(79,1794574229,3,2,8,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"pages\",\"uid\":8,\"history\":\"46\"}',6,0,'','',0,'','info',NULL,NULL),
(80,1794574261,3,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":5,\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(81,1794574283,3,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"48\"}',1,0,'','',0,'','info',NULL,NULL),
(82,1794574416,3,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":6,\"pid\":5}',5,0,'','',0,'','info',NULL,NULL),
(83,1794574431,3,1,7,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":7,\"pid\":6}',6,0,'','',0,'','info',NULL,NULL),
(84,1794574442,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','3ec9b7aec282c',1794574442.2214,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(85,1794574448,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','08ae59ac6191a',1794574448.1317,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(86,1794574456,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','2c0212aaa557b',1794574456.3455,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(87,1794574493,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','fe86098f383b0',1794574493.8267,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(88,1794574501,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','b12eda2cdf26c',1794574501.8954,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(89,1794574506,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','a11b064be46d2',1794574506.7893,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(90,1794574560,3,1,2,'sys_template',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"sys_template\",\"uid\":2,\"pid\":6}',6,0,'','',0,'','info',NULL,NULL),
(91,1794574651,3,2,2,'sys_template',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"sys_template\",\"uid\":2,\"history\":\"52\"}',6,0,'','',0,'','info',NULL,NULL),
(92,1794574663,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.20.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(93,1794824189,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.20.0.8','[\"et.richard.klein\"]',-1,-99,'','',0,'','info',NULL,NULL),
(94,1794824197,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.20.0.8','[\"et.richard.klein\"]',-1,-99,'','',0,'','info',NULL,NULL),
(95,1794824219,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.20.0.8','[\"et.richard.klein\"]',-1,-99,'','',0,'','info',NULL,NULL),
(96,1794824248,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','6043e0a5bb2ed',1794824248.3995,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(97,1794824261,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','e9794f512a672',1794824261.4792,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(98,1794824270,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','89d0dc4399ef9',1794824270.095,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(99,1794824286,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','2d756e73e28d0',1794824286.6349,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(100,1794824288,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','ea88415037843',1794824288.0059,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(101,1794824293,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','de846c4cf43df',1794824293.7824,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(102,1794824297,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','58ab341b7b546',1794824297.3229,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(103,1794824310,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','fd33e6988bfae',1794824310.858,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(104,1794824423,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','6491dfc758f38',1794824423.7945,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(105,1794844420,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','80f6f9e3a3d51',1794844420.6211,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(106,1794844470,3,1,2,'tt_address',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":2,\"pid\":4}',4,0,'','',0,'','info',NULL,NULL),
(107,1794844470,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','9d3f0059e7778',1794844470.1352,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(108,1794844531,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','393b83e3e89e3',1794844531.3535,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(109,1794844563,3,1,3,'tt_address',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":3,\"pid\":4}',4,0,'','',0,'','info',NULL,NULL),
(110,1794844563,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','bb83333657ee9',1794844563.6158,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(111,1794844570,3,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"55\"}',2,0,'','',0,'','info',NULL,NULL),
(112,1794844579,3,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"56\"}',8,0,'','',0,'','info',NULL,NULL),
(113,1794844583,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.20.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(114,1794847021,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.20.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(115,1794847025,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','ac6ca588146a8',1794847025.461,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(116,1794847622,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','49f0977835545',1794847622.2444,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(117,1794847627,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','c5ae9556d106f',1794847627.5834,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(118,1794848759,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.20.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(119,1794848972,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.20.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(120,1794850551,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.20.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(121,1794851574,3,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.20.0.8','[\"et.richard.klein\"]',-1,0,'','',0,'','info',NULL,NULL),
(122,1794908644,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.20.0.8','[\"et.richard.klein\"]',-1,-99,'','',0,'','info',NULL,NULL),
(123,1794908651,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','a46c018853bf6',1794908651.0241,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(124,1794908657,3,2,1,'tt_address',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":1,\"history\":\"57\"}',4,0,'','',0,'','info',NULL,NULL),
(125,1794908657,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','86378c9f8a5d6',1794908657.2269,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(126,1794908662,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','c4669538f5084',1794908662.9137,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(127,1794908681,3,2,1,'tt_address',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":1,\"history\":\"58\"}',4,0,'','',0,'','info',NULL,NULL),
(128,1794908681,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','27145bb1b1e6c',1794908681.1759,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(129,1794908690,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','22c39b37f7870',1794908690.6899,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(130,1794908695,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','3f7e6cb54f4dd',1794908695.1402,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(131,1794908769,3,2,2,'tt_address',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":2,\"history\":\"59\"}',4,0,'','',0,'','info',NULL,NULL),
(132,1794908769,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','8b90b248c320c',1794908769.6603,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(133,1794910888,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','b8ba0d047b0ee',1794910888.7588,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(134,1794910892,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','87befcab442ee',1794910892.4647,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(135,1794910899,3,2,2,'tt_address',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":2,\"history\":\"60\"}',4,0,'','',0,'','info',NULL,NULL),
(136,1794910899,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','0ad9224ad2454',1794910899.3996,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(137,1794913167,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','bc03b6ba7335a',1794913167.4934,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(138,1794913198,3,2,2,'tt_address',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.20.0.8','{\"table\":\"tt_address\",\"uid\":2,\"history\":\"61\"}',4,0,'','',0,'','info',NULL,NULL),
(139,1794913199,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','e96f3aa073d6a',1794913199.061,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(140,1794913231,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.20.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(141,1794931251,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.20.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(142,1794932688,3,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.20.0.8','[\"et.richard.klein\"]',-1,0,'','',0,'','info',NULL,NULL),
(143,1794992489,3,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.8','[\"et.richard.klein\"]',-1,-99,'','',0,'','info',NULL,NULL),
(144,1794992494,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(145,1794992750,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(146,1794992756,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','135374f529e53',1794992756.7149,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(147,1794992799,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','7c0eb3e955911',1794992799.5809,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(148,1794992831,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','eb14cdf478ccb',1794992831.6725,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(149,1794992835,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','7bfb185d10a48',1794992835.1671,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(150,1794992928,3,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"62\"}',3,0,'','',0,'','info',NULL,NULL),
(151,1794992949,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','b1b864a17a8c7',1794992949.1293,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(152,1794992992,3,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"63\"}',3,0,'','',0,'','info',NULL,NULL),
(153,1794993034,3,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":1,\"history\":0}',3,0,'','',0,'','info',NULL,NULL),
(154,1794993036,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','5624c79943be1',1794993036.3596,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(155,1794993039,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','12b3aad838dfe',1794993039.0683,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(156,1794993041,3,3,3,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":3,\"pid\":7}',7,0,'','',0,'','info',NULL,NULL),
(157,1794993043,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','db8943c942e6c',1794993043.241,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(158,1794993046,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','04f058cf77be8',1794993046.1478,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(159,1794993049,3,1,8,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":8,\"pid\":7}',7,0,'','',0,'','info',NULL,NULL),
(160,1794993049,3,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":8,\"history\":\"66\"}',7,0,'','',0,'','info',NULL,NULL),
(161,1794993049,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','b8957d421deb7',1794993049.9599,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(162,1794993069,3,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":8,\"history\":\"67\"}',7,0,'','',0,'','info',NULL,NULL),
(163,1794993072,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','0ccfece89abe6',1794993072.3997,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(164,1794993075,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','cbf6aef361508',1794993075.1549,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(165,1794993081,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','892672b0fbf68',1794993081.3745,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(166,1794994046,3,2,8,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":8,\"history\":\"68\"}',7,0,'','',0,'','info',NULL,NULL),
(167,1794994047,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','3256533b25fd2',1794994047.9372,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(168,1794994049,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','78a35f2ca2c2e',1794994049.142,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(169,1794994060,3,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.8','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"69\"}',3,0,'','',0,'','info',NULL,NULL),
(170,1794994062,0,0,0,'',0,0,NULL,0,'default',0,'',NULL,-1,0,'','acc49b95f4f8c',1794994062.8562,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [1] \"fileadmin\", error: Base path \"/var/www/html/.build/public/fileadmin/\" does not exist or is no directory.',''),
(171,1794994066,3,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.8','{\"username\":\"et.richard.klein\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(172,1794994480,3,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.8','[\"et.richard.klein\"]',-1,0,'','',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('3ece24b04a64547f168678eb03e71431','be_users',3,'email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'richard.klein@elementare-teilchen.de'),
('534c69f907c197c2b1f9d2aeee2f3963','tt_content',4,'pi_flexform',0,0,2147483647,0,'main/lDEF/settings.addresses/vDEF/','','',0,0,'tt_address',1,'',0,0,2147483647,0,0,''),
('7394c5374fa62dc1988acad3b493f415','be_users',1,'email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'admin@example.com'),
('9858d54a53bdb5ae7d6e2bf8da6bc254','tt_content',2,'pi_flexform',0,0,2147483647,0,'main/lDEF/settings.addresses/vDEF/','','',2,0,'tt_address',3,'',0,0,2147483647,0,0,''),
('a5f20edac7786ab1ea852d9ca709d6e0','tt_content',2,'pi_flexform',0,0,2147483647,0,'main/lDEF/settings.addresses/vDEF/','','',0,0,'tt_address',1,'',0,0,2147483647,0,0,''),
('abf19abe3a48dc753a7a1b351031644c','tt_content',4,'pi_flexform',0,0,2147483647,0,'main/lDEF/settings.addresses/vDEF/','','',1,0,'tt_address',2,'',0,0,2147483647,0,0,''),
('c5b4cac23472e69b5f41a743f703d351','tt_content',2,'pi_flexform',0,0,2147483647,0,'main/lDEF/settings.addresses/vDEF/','','',1,0,'tt_address',2,'',0,0,2147483647,0,0,''),
('f8d4b8fb757496d8abdf8be5448ffce0','tt_content',4,'pi_flexform',0,0,2147483647,0,'main/lDEF/settings.addresses/vDEF/','','',2,0,'tt_address',3,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'core','formProtectionSessionToken:1','s:64:\"c3854bdf3836e8c4e272bd580a96eabfc6c326e96bd1d7528efc9eb5ed0bc2ae\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,1737379444,1737378859,0,0,0,0,256,'','MAIN TEMPLATE',1,0,'','EXT:fluid_styled_content/Configuration/TypoScript/,EXT:osm/Configuration/TypoScript/','',0,'page = PAGE\r\npage.10 < styles.content.get',0),
(2,6,1794574651,1794574560,0,0,0,0,256,'','Enable OpenLayers 10 Templates',0,0,'plugin.tx_osm.enableOpenLayers10 = 1','','',0,'',0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_address`
--

DROP TABLE IF EXISTS `tt_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_address` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `gender` varchar(1) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `first_name` tinytext DEFAULT NULL,
  `middle_name` tinytext DEFAULT NULL,
  `last_name` tinytext DEFAULT NULL,
  `birthday` bigint(20) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_suffix` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(30) NOT NULL DEFAULT '',
  `mobile` varchar(30) NOT NULL DEFAULT '',
  `www` varchar(255) NOT NULL DEFAULT '',
  `address` tinytext DEFAULT NULL,
  `building` varchar(255) NOT NULL DEFAULT '',
  `room` varchar(255) NOT NULL DEFAULT '',
  `company` varchar(255) NOT NULL DEFAULT '',
  `position` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(20) NOT NULL DEFAULT '',
  `region` varchar(255) NOT NULL DEFAULT '',
  `country` varchar(128) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `skype` varchar(255) DEFAULT '',
  `twitter` varchar(255) DEFAULT '',
  `facebook` varchar(255) DEFAULT '',
  `instagram` varchar(255) DEFAULT '',
  `tiktok` varchar(255) DEFAULT '',
  `linkedin` varchar(255) DEFAULT '',
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `image` tinyblob DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `pid_email` (`pid`,`email`(191)),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_address`
--

LOCK TABLES `tt_address` WRITE;
/*!40000 ALTER TABLE `tt_address` DISABLE KEYS */;
INSERT INTO `tt_address` VALUES
(1,4,1794908681,1737380917,0,0,0,0,'',256,0,0,NULL,0,'{\"address\":\"\",\"birthday\":\"\",\"building\":\"\",\"categories\":\"\",\"city\":\"\",\"company\":\"\",\"country\":\"\",\"description\":\"\",\"email\":\"\",\"endtime\":\"\",\"facebook\":\"\",\"fax\":\"\",\"fe_group\":\"\",\"first_name\":\"\",\"gender\":\"\",\"hidden\":\"\",\"image\":\"\",\"instagram\":\"\",\"last_name\":\"\",\"latitude\":\"\",\"linkedin\":\"\",\"longitude\":\"\",\"middle_name\":\"\",\"mobile\":\"\",\"name\":\"\",\"phone\":\"\",\"position\":\"\",\"region\":\"\",\"room\":\"\",\"skype\":\"\",\"slug\":\"\",\"starttime\":\"\",\"tiktok\":\"\",\"title\":\"\",\"title_suffix\":\"\",\"twitter\":\"\",\"www\":\"\",\"zip\":\"\"}',0,0,0,0,'','Universität Tübingen','default-e2dbe02fa8f2089ddc2962fb738965ec','','','',0,'','','','','','','Geschwister-Scholl-Platz','','','','','Tübingen','72074','','Germany','','','','','','','','',48.52441205,9.05972173,'0',0),
(2,4,1794913198,1794844470,0,0,0,0,'',128,0,0,NULL,0,'{\"address\":\"\",\"birthday\":\"\",\"building\":\"\",\"categories\":\"\",\"city\":\"\",\"company\":\"\",\"country\":\"\",\"description\":\"\",\"email\":\"\",\"endtime\":\"\",\"facebook\":\"\",\"fax\":\"\",\"fe_group\":\"\",\"first_name\":\"\",\"gender\":\"\",\"hidden\":\"\",\"image\":\"\",\"instagram\":\"\",\"last_name\":\"\",\"latitude\":\"\",\"linkedin\":\"\",\"longitude\":\"\",\"middle_name\":\"\",\"mobile\":\"\",\"name\":\"\",\"phone\":\"\",\"position\":\"\",\"region\":\"\",\"room\":\"\",\"skype\":\"\",\"slug\":\"\",\"starttime\":\"\",\"tiktok\":\"\",\"title\":\"\",\"title_suffix\":\"\",\"twitter\":\"\",\"www\":\"\",\"zip\":\"\"}',0,0,0,0,'','Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior','default-10e20b1bb2726bd4600aae57878a70ad','','','',0,'','','','','','','','','','','','','','','','','Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\r\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\r\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.','','','','','','',48.52347617,9.05672014,'0',0),
(3,4,1794844563,1794844563,0,0,0,0,'',64,0,0,NULL,0,'',0,0,0,0,'','Technisches Rathaus','default-8dffda840c8fd42d91e9af9e899f2383','','','',0,'','','','','','','','','','','','','','','','','','','','','','','',48.52339089,9.06025528,NULL,0);
/*!40000 ALTER TABLE `tt_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,3,1794994060,1737378820,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"list_type\":\"\",\"pi_flexform\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,'list',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'osm_pi1',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"main\">\n            <language index=\"lDEF\">\n                <field index=\"settings.zoom\">\n                    <value index=\"vDEF\">14</value>\n                </field>\n                <field index=\"settings.addresses\">\n                    <el index=\"el\">\n                        <field index=\"678e4e92e348b293865823\">\n                            <value index=\"config\">\n                                <el>\n                                    <field index=\"address\">\n                                        <value index=\"vDEF\">Geschwister-Scholl-Platz, 72074 Tübingen, Deutschland</value>\n                                    </field>\n                                    <field index=\"latitude\">\n                                        <value index=\"vDEF\">48.52441205</value>\n                                    </field>\n                                    <field index=\"longitude\">\n                                        <value index=\"vDEF\">9.05972173</value>\n                                    </field>\n                                    <field index=\"marker\">\n                                        <value index=\"vDEF\">1</value>\n                                    </field>\n                                    <field index=\"markertitle\">\n                                        <value index=\"vDEF\">Universität Tübingen</value>\n                                    </field>\n                                    <field index=\"markerdescription\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                </el>\n                            </value>\n                        </field>\n                        <field index=\"6afd6acabb44a367896477\">\n                            <value index=\"config\">\n                                <el>\n                                    <field index=\"address\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                    <field index=\"latitude\">\n                                        <value index=\"vDEF\">48.52339089</value>\n                                    </field>\n                                    <field index=\"longitude\">\n                                        <value index=\"vDEF\">9.06025528</value>\n                                    </field>\n                                    <field index=\"marker\">\n                                        <value index=\"vDEF\">1</value>\n                                    </field>\n                                    <field index=\"markertitle\">\n                                        <value index=\"vDEF\">Technisches Rathaus</value>\n                                    </field>\n                                    <field index=\"markerdescription\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                </el>\n                            </value>\n                        </field>\n                        <field index=\"6afd6b3b42f3a140394427\">\n                            <value index=\"config\">\n                                <el>\n                                    <field index=\"address\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                    <field index=\"latitude\">\n                                        <value index=\"vDEF\">48.52347617</value>\n                                    </field>\n                                    <field index=\"longitude\">\n                                        <value index=\"vDEF\">9.05672014</value>\n                                    </field>\n                                    <field index=\"marker\">\n                                        <value index=\"vDEF\">1</value>\n                                    </field>\n                                    <field index=\"markertitle\">\n                                        <value index=\"vDEF\">Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior</value>\n                                    </field>\n                                    <field index=\"markerdescription\">\n                                        <value index=\"vDEF\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</value>\n                                    </field>\n                                </el>\n                            </value>\n                        </field>\n                    </el>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(2,2,1794844570,1737380830,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"list_type\":\"\",\"pi_flexform\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,'list',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'osm_pi2',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"main\">\n            <language index=\"lDEF\">\n                <field index=\"settings.addresses\">\n                    <value index=\"vDEF\">1,2,3</value>\n                </field>\n                <field index=\"settings.zoom\">\n                    <value index=\"vDEF\">14</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(3,7,1794993041,1794574171,1,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"list_type\":\"\",\"pi_flexform\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"categories\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'default',0,NULL,'list',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'osm_pi1',0,'',1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"main\">\n            <language index=\"lDEF\">\n                <field index=\"settings.zoom\">\n                    <value index=\"vDEF\">14</value>\n                </field>\n                <field index=\"settings.addresses\">\n                    <el index=\"el\">\n                        <field index=\"678e4e92e348b293865823\">\n                            <value index=\"config\">\n                                <el>\n                                    <field index=\"address\">\n                                        <value index=\"vDEF\">Geschwister-Scholl-Platz, 72074 Tübingen, Deutschland</value>\n                                    </field>\n                                    <field index=\"latitude\">\n                                        <value index=\"vDEF\">48.52441205</value>\n                                    </field>\n                                    <field index=\"longitude\">\n                                        <value index=\"vDEF\">9.05972173</value>\n                                    </field>\n                                    <field index=\"marker\">\n                                        <value index=\"vDEF\">1</value>\n                                    </field>\n                                    <field index=\"markertitle\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                    <field index=\"markerdescription\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                </el>\n                            </value>\n                        </field>\n                    </el>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','0','',0,0,'',124,0,0,0,'',0,'','','',0,0),
(4,8,1794844579,1794574204,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"list_type\":\"\",\"pi_flexform\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,'list',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'osm_pi2',0,'',1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"main\">\n            <language index=\"lDEF\">\n                <field index=\"settings.addresses\">\n                    <value index=\"vDEF\">1,2,3</value>\n                </field>\n                <field index=\"settings.zoom\">\n                    <value index=\"vDEF\">14</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','0','',0,0,'',124,0,0,0,'',0,'','','',0,0),
(5,1,1794574283,1794574261,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"pages\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,'menu_sitemap_pages',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(6,5,1794574416,1794574416,0,0,0,0,'',256,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,'menu_subpages',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(7,6,1794574431,1794574431,0,0,0,0,'',256,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,'menu_subpages',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(8,7,1794994046,1794993049,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"list_type\":\"\",\"pi_flexform\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,'list',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'osm_pi1',0,'',1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"main\">\n            <language index=\"lDEF\">\n                <field index=\"settings.zoom\">\n                    <value index=\"vDEF\">14</value>\n                </field>\n                <field index=\"settings.addresses\">\n                    <el index=\"el\">\n                        <field index=\"678e4e92e348b293865823\">\n                            <value index=\"config\">\n                                <el>\n                                    <field index=\"address\">\n                                        <value index=\"vDEF\">Geschwister-Scholl-Platz, 72074 Tübingen, Deutschland</value>\n                                    </field>\n                                    <field index=\"latitude\">\n                                        <value index=\"vDEF\">48.52441205</value>\n                                    </field>\n                                    <field index=\"longitude\">\n                                        <value index=\"vDEF\">9.05972173</value>\n                                    </field>\n                                    <field index=\"marker\">\n                                        <value index=\"vDEF\">1</value>\n                                    </field>\n                                    <field index=\"markertitle\">\n                                        <value index=\"vDEF\">Universität Tübingen</value>\n                                    </field>\n                                    <field index=\"markerdescription\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                </el>\n                            </value>\n                        </field>\n                        <field index=\"6afd6acabb44a367896477\">\n                            <value index=\"config\">\n                                <el>\n                                    <field index=\"address\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                    <field index=\"latitude\">\n                                        <value index=\"vDEF\">48.52339089</value>\n                                    </field>\n                                    <field index=\"longitude\">\n                                        <value index=\"vDEF\">9.06025528</value>\n                                    </field>\n                                    <field index=\"marker\">\n                                        <value index=\"vDEF\">1</value>\n                                    </field>\n                                    <field index=\"markertitle\">\n                                        <value index=\"vDEF\">Technisches Rathaus</value>\n                                    </field>\n                                    <field index=\"markerdescription\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                </el>\n                            </value>\n                        </field>\n                        <field index=\"6afd6b3b42f3a140394427\">\n                            <value index=\"config\">\n                                <el>\n                                    <field index=\"address\">\n                                        <value index=\"vDEF\"></value>\n                                    </field>\n                                    <field index=\"latitude\">\n                                        <value index=\"vDEF\">48.52347617</value>\n                                    </field>\n                                    <field index=\"longitude\">\n                                        <value index=\"vDEF\">9.05672014</value>\n                                    </field>\n                                    <field index=\"marker\">\n                                        <value index=\"vDEF\">1</value>\n                                    </field>\n                                    <field index=\"markertitle\">\n                                        <value index=\"vDEF\">Alter Botanischer Garten - Test address with longer text inside the popup to test popup size and line break behavior</value>\n                                    </field>\n                                    <field index=\"markerdescription\">\n                                        <value index=\"vDEF\">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.\nAt vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</value>\n                                    </field>\n                                </el>\n                            </value>\n                        </field>\n                    </el>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','0','',0,0,'',124,0,0,0,'',0,'','','',0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  `update_comment` longtext DEFAULT NULL,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-18 10:38:32
